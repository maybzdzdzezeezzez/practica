﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductionSystem.Models
{
    public class ProductMaterial
    {
        public int ProductId { get; set; }
        public int MaterialId { get; set; }
        public double QuantityPerProduct { get; set; }
        public double Cost { get; set; }
        public double DefectPercent { get; set; }
    }

    public class Product
    {
        public int Id { get; set; }
        public string Article { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public double MinPartnerPrice { get; set; }
        public double RollWidth { get; set; }
        public double CalculatedCost { get; set; }
    }

    public class Material
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Unit { get; set; }
        public double Cost { get; set; }
        public double DefectPercent { get; set; }
    }
}
