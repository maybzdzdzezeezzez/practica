﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ProductionSystem.Data;
using ProductionSystem.Models;

namespace ProductionSystem
{
    public partial class MainWindow : Window
    {
        private DatabaseService dbService = new DatabaseService();

        public MainWindow()
        {
            InitializeComponent();
            LoadProducts();
            AddProductButton.Click += AddProductButton_Click;
            EditProductButton.Click += EditProductButton_Click;
        }

        private void LoadProducts()
        {
            List<Product> products = dbService.GetProducts();
            ProductDataGrid.ItemsSource = products;
        }

        // Добавить
        private void AddProductButton_Click(object sender, RoutedEventArgs e)
        {
            ProductEditWindow editWindow = new ProductEditWindow();
            bool? result = editWindow.ShowDialog();
            if (result == true)
            {
                // Сохранить
                LoadProducts();
            }
        }

        // Редактировать
        private void EditProductButton_Click(object sender, RoutedEventArgs e)
        {
            if (ProductDataGrid.SelectedItem is Product selectedProduct)
            {
                ProductEditWindow editWindow = new ProductEditWindow(selectedProduct);
                bool? result = editWindow.ShowDialog();
                if (result == true)
                {
                    LoadProducts();
                }
            }
            else
            {
                MessageBox.Show("Сначала выберите продукт для редактирования.", "Информация",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}
