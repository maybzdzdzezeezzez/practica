﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using ProductionSystem;
using ProductionSystem.Data;
using ProductionSystem.Models;

namespace ProductionSystem
{
    public partial class ProductEditWindow : Window
    {
        private readonly DatabaseService _db = new DatabaseService();
        private readonly Product editingProduct;
        private readonly bool isEditMode;

        public ProductEditWindow()
        {
            InitializeComponent();
            editingProduct = new Product();
            isEditMode = false;
            LoadProductTypes();
        }

        public ProductEditWindow(Product product) : this()
        {
            editingProduct = product;
            isEditMode = true;
            FillFields();
        }

        private void LoadProductTypes()
        {
            var types = _db.GetProductTypes();
            ProductTypeComboBox.ItemsSource = types;
            ProductTypeComboBox.DisplayMemberPath = "Name";
            ProductTypeComboBox.SelectedValuePath = "Id";

            if (!isEditMode)
                ProductTypeComboBox.SelectedIndex = 0;
        }


        private void FillFields()
        {
            ArticleTextBox.Text = editingProduct.Article;
            NameTextBox.Text = editingProduct.Name;

            ProductTypeComboBox.SelectedValue = editingProduct.ProductTypeId;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверка обязательных полей
            if (string.IsNullOrWhiteSpace(ArticleTextBox.Text) ||
                string.IsNullOrWhiteSpace(NameTextBox.Text) ||
                string.IsNullOrWhiteSpace(MinPartnerPriceTextBox.Text) ||
                string.IsNullOrWhiteSpace(RollWidthTextBox.Text) ||
                ProductTypeComboBox.SelectedItem == null)
            {
                MessageBox.Show(
                    "Пожалуйста, заполните все поля.",
                    "Ошибка ввода данных",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning
                );
                return;
            }

            // Проверка формата числовых полей
            if (!double.TryParse(MinPartnerPriceTextBox.Text, out double minPrice) || minPrice < 0)
            {
                MessageBox.Show(
                    "Минимальная цена должна быть числом больше или равным 0.",
                    "Ошибка ввода данных",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );
                return;
            }

            if (!double.TryParse(RollWidthTextBox.Text, out double rollWidth) || rollWidth < 0)
            {
                MessageBox.Show(
                    "Ширина рулона должна быть числом больше или равным 0.",
                    "Ошибка ввода данных",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );
                return;
            }

            // Сохранение данных в объект продукта
            editingProduct.Article = ArticleTextBox.Text.Trim();
            editingProduct.Name = NameTextBox.Text.Trim();
            editingProduct.MinPartnerPrice = minPrice;
            editingProduct.RollWidth = rollWidth;
            editingProduct.ProductTypeId = (int)ProductTypeComboBox.SelectedValue;

            try
            {
                if (isEditMode)
                {
                    _db.UpdateProduct(editingProduct);
                }
                else
                {
                    _db.AddProduct(editingProduct);
                }

                DialogResult = true; // Закрытие окна с успехом
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Ошибка при сохранении продукта:\n{ex.Message}",
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );
            }
        }



        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
