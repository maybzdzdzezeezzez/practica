﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ProductionSystem.Models;

namespace ProductionSystem.Services
{
    public class ProductCostCalculator
    {
        public static double CalculateProductCost(List<ProductMaterial> materials)
        {
            double totalCost = 0;

            foreach (var mat in materials)
            {
                double adjustedCost = mat.Cost * mat.QuantityPerProduct * (1 + mat.DefectPercent / 100);
                totalCost += adjustedCost;
            }

            totalCost = Math.Round(totalCost, 2);

            if (totalCost < 0) totalCost = 0;

            return totalCost;
        }
    }
}
