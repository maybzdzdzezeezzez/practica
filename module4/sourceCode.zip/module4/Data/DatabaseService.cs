﻿using ProductionSystem.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ProductionSystem.Services;
namespace ProductionSystem.Data
{
    public class DatabaseService
    {
        private string ConnectionString = "Server=localhost;Database=production_system;Trusted_Connection=True;";

        public List<Product> GetProducts()
        {
            var products = new List<Product>();

            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();

                var cmd = new SqlCommand(
                    "SELECT Id, Article, Name, MinPartnerPrice, RollWidth FROM product;", conn);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        products.Add(new Product
                        {
                            Id = Convert.ToInt32(reader["Id"]),
                            Article = reader["Article"].ToString() ?? string.Empty,
                            Name = reader["Name"].ToString() ?? string.Empty,
                            MinPartnerPrice = Convert.ToDouble(reader["MinPartnerPrice"]),
                            RollWidth = Convert.ToDouble(reader["RollWidth"])
                        });
                    }
                }
            }

            foreach (var product in products)
            {
                product.CalculatedCost = GetProductCost(product.Id);
            }

            return products;
        }

        private double GetProductCost(int productId)
        {
            var materials = new List<ProductMaterial>();

            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();

                var cmd = new SqlCommand(@"
                    SELECT pm.QuantityPerProduct, m.Cost, m.DefectPercent
                    FROM product_material pm
                    JOIN material m ON pm.MaterialId = m.Id
                    WHERE pm.ProductId = @productId;", conn);

                cmd.Parameters.AddWithValue("@productId", productId);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        materials.Add(new ProductMaterial
                        {
                            QuantityPerProduct = Convert.ToDouble(reader["QuantityPerProduct"]),
                            Cost = Convert.ToDouble(reader["Cost"]),
                            DefectPercent = Convert.ToDouble(reader["DefectPercent"])
                        });
                    }
                }
            }

            return ProductCostCalculator.CalculateProductCost(materials);
        }

        public List<ProductType> GetProductTypes()
        {
            var types = new List<ProductType>();
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                var cmd = new SqlCommand("SELECT Id, Name, Coefficient FROM product_type;", conn);
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        types.Add(new ProductType
                        {
                            Id = Convert.ToInt32(reader["Id"]),
                            Name = reader["Name"].ToString() ?? string.Empty,
                            Coefficient = Convert.ToDouble(reader["Coefficient"])
                        });
                    }
                }
            }
            return types;
        }


        public void AddProduct(Product product)
        {
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                var cmd = new SqlCommand(@"
            INSERT INTO product (Article, Name, MinPartnerPrice, RollWidth, ProductTypeId)
            VALUES (@Article, @Name, @MinPartnerPrice, @RollWidth, @ProductTypeId);", conn);

                cmd.Parameters.AddWithValue("@Article", product.Article);
                cmd.Parameters.AddWithValue("@Name", product.Name);
                cmd.Parameters.AddWithValue("@MinPartnerPrice", product.MinPartnerPrice);
                cmd.Parameters.AddWithValue("@RollWidth", product.RollWidth);
                cmd.Parameters.AddWithValue("@ProductTypeId", product.ProductTypeId);

                cmd.ExecuteNonQuery();
            }
        }

        public void UpdateProduct(Product product)
        {
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                var cmd = new SqlCommand(@"
            UPDATE product
            SET Article = @Article,
                Name = @Name,
                MinPartnerPrice = @MinPartnerPrice,
                RollWidth = @RollWidth,
                ProductTypeId = @ProductTypeId
            WHERE Id = @Id;", conn);

                cmd.Parameters.AddWithValue("@Id", product.Id);
                cmd.Parameters.AddWithValue("@Article", product.Article);
                cmd.Parameters.AddWithValue("@Name", product.Name);
                cmd.Parameters.AddWithValue("@MinPartnerPrice", product.MinPartnerPrice);
                cmd.Parameters.AddWithValue("@RollWidth", product.RollWidth);
                cmd.Parameters.AddWithValue("@ProductTypeId", product.ProductTypeId);

                cmd.ExecuteNonQuery();
            }
        }


        public List<ProductMaterialView> GetMaterialsForProduct(int productId)
        {
            var result = new List<ProductMaterialView>();

            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();

                var cmd = new SqlCommand(@"
        SELECT 
            m.Name,
            m.Unit,
            pm.QuantityPerProduct,
            m.Cost,
            m.DefectPercent
        FROM product_material pm
        JOIN material m ON pm.MaterialId = m.Id
        WHERE pm.ProductId = @productId", conn);

                cmd.Parameters.AddWithValue("@productId", productId);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(new ProductMaterialView
                        {
                            MaterialName = reader["Name"].ToString(),
                            Unit = reader["Unit"].ToString(),
                            QuantityPerProduct = Convert.ToDouble(reader["QuantityPerProduct"]),
                            Cost = Convert.ToDouble(reader["Cost"]),
                            DefectPercent = Convert.ToDouble(reader["DefectPercent"])
                        });
                    }
                }
            }

            return result;
        }



    }
}
