﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace ProductionSystem.Services
{
    public class MaterialCalculationService
    {
        private readonly string _connectionString =
            "Server=localhost;Database=production_system;Trusted_Connection=True;";
        public int CalculateRequiredMaterial(
            int productTypeId,
            int materialTypeId,
            int productCount,
            double parameter1,
            double parameter2,
            double stockQuantity)
        {
            // Проверка входных данных
            if (productTypeId <= 0 ||
                materialTypeId <= 0 ||
                productCount <= 0 ||
                parameter1 <= 0 ||
                parameter2 <= 0 ||
                stockQuantity < 0)
            {
                return -1;
            }

            double productTypeCoefficient;
            double defectPercent;

            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();

                // коэффициент типа продукции
                var coefCmd = new SqlCommand(
                    "SELECT Coefficient FROM product_type WHERE Id = @id",
                    conn);
                coefCmd.Parameters.AddWithValue("@id", productTypeId);

                var coefObj = coefCmd.ExecuteScalar();
                if (coefObj == null)
                    return -1;

                productTypeCoefficient = Convert.ToDouble(coefObj);

                // средний процент брака по типу материала
                var defectCmd = new SqlCommand(@"
                    SELECT AVG(DefectPercent)
                    FROM material
                    WHERE MaterialTypeId = @materialTypeId",
                    conn);

                defectCmd.Parameters.AddWithValue("@materialTypeId", materialTypeId);

                var defectObj = defectCmd.ExecuteScalar();
                defectPercent = defectObj == DBNull.Value
                    ? 0
                    : Convert.ToDouble(defectObj);
            }

            // Расчёт потребности
            double perProduct = parameter1 * parameter2 * productTypeCoefficient;
            if (perProduct <= 0)
                return -1;

            double totalRequired = perProduct * productCount;

            // Учет брака
            totalRequired *= (1 + defectPercent / 100.0);

            // Учет склада
            double needToBuy = totalRequired - stockQuantity;

            if (needToBuy <= 0)
                return 0;

            // Округление вверх
            return (int)Math.Ceiling(needToBuy);
        }
    }
}
