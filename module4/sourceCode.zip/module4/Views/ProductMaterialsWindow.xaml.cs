﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using ProductionSystem.Data;
using ProductionSystem.Models;

namespace ProductionSystem.Views
{
    public partial class ProductMaterialsWindow : Window
    {
        private readonly DatabaseService _db = new DatabaseService();

        public ProductMaterialsWindow(Product product)
        {
            InitializeComponent();
            LoadMaterials(product.Id);
            Title = $"Материалы: {product.Name}";
        }

        private void LoadMaterials(int productId)
        {
            MaterialsDataGrid.ItemsSource = _db.GetMaterialsForProduct(productId);
        }
    }
}
